function Inicio() {
    return (
        <div>
            <h1>Gilmar</h1>
            <p>Gilmar aluno do FuturoDev, almejando uma vaga como desenvolvedor.</p>
            <h2>Minhas Habilidades</h2>
            <li>Java</li>
            <li>Javascript</li>
            <li>PostgreSQL</li>            
            <li>Spring Boot</li>
        </div>
    )

}
export default Inicio




