function Battle(){
    return(
        <h1>Batalha</h1>
    );
}

export default Battle;