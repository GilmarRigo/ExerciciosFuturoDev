import { Link } from "react-router-dom";

function Home(){   
    return(  
      
    <Link className="linkBotao" to="battle">Novo Jogo</Link>
     
    );
}

export default Home;