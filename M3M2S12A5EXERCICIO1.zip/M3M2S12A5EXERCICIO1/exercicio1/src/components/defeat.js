function Defeat(){
    return(
        <h1>Derrota</h1>
    );
}

export default Defeat;