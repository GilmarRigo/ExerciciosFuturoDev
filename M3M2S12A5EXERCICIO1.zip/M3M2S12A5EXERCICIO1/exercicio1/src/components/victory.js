function Victory(){
    return(
        <h1>Vitória</h1>
    );
}

export default Victory;