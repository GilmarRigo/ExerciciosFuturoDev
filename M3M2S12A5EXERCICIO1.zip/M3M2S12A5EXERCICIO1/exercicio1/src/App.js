import {Route, Switch} from 'react-router-dom'
import './App.css';
import Home from "./components/home"
import Battle from "./components/battle"
import Victory from './components/victory';
import Defeat from './components/defeat';


function App() {
  return (

    <Switch>

      <Route path="/battle" component={Battle}/>
      <Route path="/victory" component={Victory}/>
      <Route path="/defeat" component={Defeat}/>
      <Route path="/" component={Home}/>     

     </Switch>
  
   
   );
}

export default App;
