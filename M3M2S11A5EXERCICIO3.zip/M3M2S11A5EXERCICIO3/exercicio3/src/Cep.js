
function RenderezaCep(){ 
    
    let cep = 0;
    let element = document.getElementById('btn')
    element.addEventListener("click", () => {
        let meuCep = document.getElementById('inputCep').value
        pegaCep(meuCep)
        //let inputCep = '';

    })
    async function pegaCep(cepp) {
        console.log(cepp)
        cep = await (await fetch(`https://brasilapi.com.br/api/cep/v2/${cepp}`)).json()
        console.log(cep + 'oi') 
        if(cep.cep !== undefined){                                                  
        document.getElementById("cep1").innerHTML = 'CEP - ' + cep.city;        
        document.getElementById('state1').innerHTML = 'ESTADO - ' + cep.state;  
        document.getElementById('city1').innerHTML = 'CIDADE - ' + cep.city;         
    }else{
        alert('CEP NÃO ENCONTRADO!')
}   
    }  
    
    return(       
        
    <div>
        <h1>Digite o CEP</h1>    
        <input type="text" id="inputCep" required></input>
        <button id="btn">Pegar CEP </button>  

        <div id="cep1"></div>
        <div id="espaco1"></div>
        <div id="state1"></div>
        <div id="city1"></div>
    </div> 
    )
}

export default RenderezaCep;

