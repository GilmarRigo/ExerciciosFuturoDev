import logo from './logo.svg';
import './App.css';
import RenderezaCep from './Cep'

function App() {
  return (
    <div>
      <RenderezaCep></RenderezaCep>
    </div>
  );
}

export default App;
