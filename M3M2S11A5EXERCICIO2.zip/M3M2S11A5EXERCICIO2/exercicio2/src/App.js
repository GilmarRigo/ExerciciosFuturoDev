import logo from './logo.svg';
import './App.css';
import Calculo from './components/calculo';

function App() {

  return (
    <div className="App">
      <Calculo></Calculo>
    </div>
  );
}

export default App;
