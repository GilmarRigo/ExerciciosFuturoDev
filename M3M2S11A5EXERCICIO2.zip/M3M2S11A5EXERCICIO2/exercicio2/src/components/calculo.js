function Calculo(){

    let resultado = 0;  
    
   

    function adicao(){           
        resultado = resultado + 1           
        document.getElementById("total").innerHTML = resultado;
    }

    function subtracao() {
        if(resultado ===0 ){       
        } else {
        resultado = resultado - 1
        document.getElementById("total").innerHTML = resultado;        
        }      
    }
    return(
        <div>
            <button className='adicao' value='1' onClick={adicao}>+</button>
            <button className='subtracao' value='2' onClick={subtracao}>-</button>            
            <br></br>
            <button className='total' id="total" >{resultado}</button>            
        </div>
    )
}
export default Calculo