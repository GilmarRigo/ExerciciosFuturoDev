import React from "react";

function LocalizaPokemon() {    

  async function pegaPoke(poke) {    
    console.log(poke)
    const pokemon = await (await fetch (`https://pokeapi.co/api/v2/pokemon/${poke}`)).json()
    console.log(pokemon)
    for(const key in pokemon.stats){
        console.log(pokemon.stats[key].stat.name)
        const status = pokemon.stats[key].stat.name
        const baseState = pokemon.stats[key].base_stat        
        const paragrafo = document.createElement('p')
        paragrafo.innerHTML = `${status}:${baseState}`
        document.getElementById('id-lista-informacao').appendChild(paragrafo)        
    }    
}
const [ pokemon, setPokemon] = React.useState('');

const onSubmit = (e) => {
    e.preventDefault();
    const pokemonEscolhido = pokemon;

    pegaPoke(pokemonEscolhido);
    
}
  return (
    <div>
        <h1>Pokemon</h1>

          <form onSubmit={onSubmit}>
              <label for="">Escolha seu pokemon</label>
              <input value={pokemon} onChange={(e) => setPokemon("pikachu")} type="radio" name="pokemon" id="id-pikachu"></input>
              <label for="id-pickachi">Pikachu</label>
              <input value={pokemon} onChange={(e) => setPokemon("charmander")} type="radio" name="pokemon" id="id-charmander"></input>
              <label for="id-charmander">Charmander</label>
              <input value={pokemon} onChange={(e) => setPokemon("bulbasaur")} type="radio" name="pokemon" id="id-bulbasaur"></input>
              <label for="id-bulbasaur">Bulbasaur</label>
              <input value={pokemon} onChange={(e) => setPokemon("squirtle")}type="radio" name="pokemon" id="id-squirtle"></input>
              <label for="id-Squirtle">Squirtle</label>
              <button type="submit" id="btn">Pesquisar</button>      
          </form>
             <div id="id-lista-informacao">  </div>
  </div>    
  );

}
export default LocalizaPokemon;