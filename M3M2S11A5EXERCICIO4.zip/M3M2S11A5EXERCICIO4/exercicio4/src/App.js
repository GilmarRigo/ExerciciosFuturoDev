import LocalizaPokemon from "./Pokemon";

function App() {

  return (
<LocalizaPokemon></LocalizaPokemon>
   
  );

}
export default App;




