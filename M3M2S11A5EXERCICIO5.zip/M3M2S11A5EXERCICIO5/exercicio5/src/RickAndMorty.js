function Buscar () {

    fetch('https://rickandmortyapi.com/api/character', {
        Method: 'GET'
      })
      .then(response => response.json())
      .then(function(json){
  
        var container = document.querySelector('.container');
        
  
        json.results.map(function(results){
            if(results.status === 'Alive'){
              console.log(results);
            
            container.innerHTML+=`
           <div> <img src=` + results.image + ` > </div>  
           <div>`+ results.name + `</div>
           <div>`+ results.status + `</div>
           <div>`+ results.species + `</div>
            
            <hr>
            `;
         }
          })
      })

    return (
        <div class="container"></div>
    );
}

export default Buscar;