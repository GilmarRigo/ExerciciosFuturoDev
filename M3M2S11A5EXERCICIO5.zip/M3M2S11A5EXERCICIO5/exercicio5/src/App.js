import Buscar from './RickAndMorty.js'
import './App.css';

function App() {
  return (
    <div>
      <Buscar></Buscar>
    </div>
  );
}

export default App;
